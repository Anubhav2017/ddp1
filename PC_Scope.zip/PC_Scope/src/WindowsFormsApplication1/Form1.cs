﻿//#define USE_LIBUSB

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;
using System.Windows.Forms.DataVisualization.Charting;
using LibUsbDotNet;
using LibUsbDotNet.Main;
using System.Management;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        /*calls contains information about resolution*/
        public class Resolution
        {
            /*number of samples*/
            public int numSamples;
            /*scope sample rate*/
            public int sampleRate;
            /**/
            public double xStep;
            /*string description*/
            public String caption;
            
            /*calss constructor*/
            public Resolution(String caption,double xStep,int numSamples,int sampleRate)
            {
                this.caption = caption;
                this.xStep = xStep;
                this.numSamples = numSamples;
                this.sampleRate = sampleRate;
            }

            /*ToString ovveride function*/
            public override String ToString()
            {
                return this.caption;
            }
        }

        /*Supported resolutions*/
        public static readonly Resolution RESOLUTION_500US = new Resolution("500us", 0.5, 150, 30000);
        public static readonly Resolution RESOLUTION_1MS = new Resolution("1ms", 1, 200, 20000);
        public static readonly Resolution RESOLUTION_2MS = new Resolution("2ms", 2, 400, 20000);
        public static readonly Resolution RESOLUTION_5MS = new Resolution("5ms", 5, 1000, 20000);
        public static readonly Resolution RESOLUTION_10MS = new Resolution("10ms", 10, 1000, 10000);
        public static readonly Resolution RESOLUTION_20MS = new Resolution("20ms", 20, 1000, 5000);
        public static readonly Resolution RESOLUTION_50MS = new Resolution("50ms", 50, 1000, 2000);
        public static readonly Resolution RESOLUTION_100MS = new Resolution("100ms", 100, 1000, 1000);

        /*array with supported resolutions*/
        public static readonly Resolution[] resolutionOptions = 
        {
            RESOLUTION_500US,
            RESOLUTION_1MS,RESOLUTION_2MS,RESOLUTION_5MS,
            RESOLUTION_10MS,RESOLUTION_20MS,RESOLUTION_50MS,
            RESOLUTION_100MS
        };

        /*emun with trigger modes*/
        public enum TriggerMode : int
        {
            DISABLED = 0x0, NORMAL = 0x1, AUTO = 0x2, SINGLE = 0x3
        }

        /*maximum samples in VCP buffer*/
        const int maxSamplesVCPBuffer = 5000;
        /*maximum samples send over VCP*/
        const int maxSamplesVCPFW = 20000;
        /*how many buffers we have*/
        int sampleBufferCount = maxSamplesVCPFW / maxSamplesVCPBuffer;
        /*vcp buffer number*/
        private int sampleBufferNum=0;
        /*bytes per one sample*/
        const int bytesPerSample = 2;
        /*maximum value in sample*/
        const int maxValue = 4095;
        /*max voltage*/
        const double maxVoltage = 3300;

        /*number of samples expected on VCP*/
        volatile int vcpSamplesCount;

        /*number of samples */
        const int numBytes = maxSamplesVCPBuffer;
        /*conversion factor sample to voltage*/
        const double sampleToVoltage = maxVoltage / maxValue;

        /*used sample reate */
        double sampleRate;
        /*sample index to ms*/
        double sampleIndexToMs;
        /*maximum X axe position*/
        double maxAxisX;
        /*trigger value*/
        int triggerValue;
        /*trigger selection*/
        bool triggerRisingEdge = true;
        /*use trigger?*/
        bool triggerRunning = true;
        /*number of received bytes*/
        volatile int numberOfDataRecieved;
        /*number of received samples*/
        volatile int numberOfSamplesRevieced;

        /*is VCP in use?*/
        private bool VCP_Open = false;//use application VCP?

        //static bool _continue;
#if USE_LIBUSB
        static UsbDevice MyUsbD evice;
        static UsbDeviceFinder MyUsbFinder = new UsbDeviceFinder(1155, 13109);
        ErrorCode ec = ErrorCode.None;
        UsbEndpointReader reader;
        UsbEndpointWriter writer;
        Thread USB_receive;
#else
        /*serial port instance hadle*/
        static SerialPort _serialPort;
#endif
        /*buffer for received data*/
        byte[] readBuffer;
        /*bytes to read from VCP*/
        byte readByte = 0;
        /*is scope in runnig state?*/
        volatile bool running = true;

        /*Form constructor*/
        public Form1()
        {
            /*component initialization*/
            InitializeComponent();
           
            

            /*set default resolution*/
            sampleRate = RESOLUTION_10MS.sampleRate;
           
            /*calculate sample to ms index*/
            sampleIndexToMs = (1e3) / (sampleRate * bytesPerSample);
            /*calculate maximum X axis value*/
            maxAxisX = sampleIndexToMs * maxSamplesVCPBuffer * bytesPerSample;

            /*create new read buffer*/
            readBuffer = new byte[RESOLUTION_10MS.numSamples*2];
            /*set number of samples which we want to receive*/
            vcpSamplesCount = RESOLUTION_10MS.numSamples;
            /*check if we receive more bytes than is our buffer*/
            if (vcpSamplesCount > maxSamplesVCPBuffer)
            {
                /*check how many buffers we receiving*/
                int tempval=vcpSamplesCount/maxSamplesVCPBuffer;
                /*check if last buffer is not full*/
                if (vcpSamplesCount > (tempval * maxSamplesVCPBuffer))
                {
                    /*receive one more buffer*/
                    sampleBufferCount = tempval + 1;
                }
                else 
                {
                    /*receive only full buffers*/
                    sampleBufferCount = tempval;
                }
                vcpSamplesCount = maxSamplesVCPBuffer;
            }else{
                /*receive one buffer*/
                sampleBufferCount=1;
            }


            /*create chart description X*/
            chart1.ChartAreas[0].AxisY.Maximum = maxVoltage;
            chart1.ChartAreas[0].AxisY.Minimum = 0;
            chart1.ChartAreas[0].AxisY.Interval = 250;

            /*create chart description Y*/
            chart1.ChartAreas[0].AxisX.Maximum = maxAxisX;
            chart1.ChartAreas[0].AxisX.Minimum = 0;
            chart1.ChartAreas[0].AxisX.Interval = 10;

            /*start the connection Timer*/
            timer1.Start();//start the connection timer

        }
        /*Connection button click, not used*/
        private void sendButton_Click(object sender, EventArgs e)
        {
#if !USE_LIBUSB
            string port_name;
       
            // Create a new SerialPort object with default settings.
            _serialPort = new SerialPort();

            _serialPort.Encoding = System.Text.Encoding.GetEncoding(28591);

            // Set the read/write timeouts
            _serialPort.ReadTimeout = 500;
            _serialPort.WriteTimeout = 500;
            port_name = AutodetectSTM32VCPPort();//find stm vistual com port
            /*check if the com port is connected*/
            if(port_name==null){
                MessageBox.Show("STM VCP is not connected to PC");
                return;
            }
            _serialPort.PortName = port_name;
            _serialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
            try
            {
                _serialPort.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot open Serial com port");
                return;
            }
            progressBar1.Value = 100;

#else
            try
            {
                // Find and open the usb device.
                MyUsbDevice = UsbDevice.OpenUsbDevice(MyUsbFinder);

                // If the device is open and ready
                if (MyUsbDevice == null) throw new Exception("Device Not Found.");

                // If this is a "whole" usb device (libusb-win32, linux libusb-1.0)
                // it exposes an IUsbDevice interface. If not (WinUSB) the 
                // 'wholeUsbDevice' variable will be null indicating this is 
                // an interface of a device; it does not require or support 
                // configuration and interface selection.
                IUsbDevice wholeUsbDevice = MyUsbDevice as IUsbDevice;
                if (!ReferenceEquals(wholeUsbDevice, null))
                {
                    // This is a "whole" USB device. Before it can be used, 
                    // the desired configuration and interface must be selected.

                    // Select config #1
                    wholeUsbDevice.SetConfiguration(1);

                    // Claim interface #0.
                    wholeUsbDevice.ClaimInterface(0);
                }
                reader = MyUsbDevice.OpenEndpointReader(ReadEndpointID.Ep01);
                writer = MyUsbDevice.OpenEndpointWriter(WriteEndpointID.Ep01);

                // Setup trigger
                setTriggerVoltage(1500);
                setNumberOfSamples((int)numberOfSamplesControl.Value);
                setSampleRate((int)sampleRateValue.Value);
                setRisingEdge(triggerRisingEdge);

                USB_receive = new Thread(USBReceive);
                // open read endpoint 1.

                USB_receive.Start();
            }
            catch (Exception ex)
            {
                if(USB_receive != null)
                    USB_receive.Abort();
                MessageBox.Show(ex.Message, "Error");
                Console.WriteLine();
                Console.WriteLine((ec != ErrorCode.None ? ec + ":" : String.Empty) + ex.Message);
            }     
#endif
        }
#if USE_LIBUSB
        private void USBReceive()
        {
            try
            {
                while (running && ((ec == ErrorCode.None) || (ec == ErrorCode.IoTimedOut)))
                {
                    // If the device hasn't sent data in the last 5 seconds,
                    // a timeout error (ec = IoTimedOut) will occur. 
                    //ec = reader.Read(readBuffer, 0, numBytes, 5000, out bytesRead);
                    int bytesRead;
                    ec = reader.Transfer(readBuffer, 0, numBytes, 5000, out bytesRead);
                    numberOfDataRecieved = bytesRead;
                    numberOfSamplesRevieced = bytesRead / bytesPerSample;
                    lock (USB_receive)
                    {
                        if (running && ec == ErrorCode.None)
                        {
                            this.BeginInvoke(new EventHandler(DoUpdate));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine((ec != ErrorCode.None ? ec + ":" : String.Empty) + ex.Message);
                MessageBox.Show(ex.Message, "Error");
            }
            finally
            {
                if (ec != ErrorCode.None)
                {
                    MessageBox.Show(ec.ToString(), "Error");
                }
                if (MyUsbDevice != null)
                {
                    if (MyUsbDevice.IsOpen)
                    {
                        // If this is a "whole" usb device (libusb-win32, linux libusb-1.0)
                        // it exposes an IUsbDevice interface. If not (WinUSB) the 
                        // 'wholeUsbDevice' variable will be null indicating this is 
                        // an interface of a device; it does not require or support 
                        // configuration and interface selection.
                        IUsbDevice wholeUsbDevice = MyUsbDevice as IUsbDevice;
                        if (!ReferenceEquals(wholeUsbDevice, null))
                        {
                            // Release interface #0.
                            wholeUsbDevice.ReleaseInterface(0);
                        }

                        MyUsbDevice.Close();
                    }
                    MyUsbDevice = null;

                    // Free usb resources

                }

                // Wait for user input..
                //Console.ReadKey();
            }
        }
#endif
        /*handle VCP data receiving*/
        public  void DataReceivedHandler(
                        object sender,
                        SerialDataReceivedEventArgs e)
        {
            /*handle errors*/
            try
            {
                /*get VCP instance*/
                SerialPort sp = (SerialPort)sender;
                /*check if we received enaugh of data*/
                if (sp.BytesToRead >= (vcpSamplesCount * bytesPerSample))
                {
                    /*read data from VCP*/
                    sp.Read(readBuffer, sampleBufferNum * vcpSamplesCount, vcpSamplesCount * bytesPerSample);
                    /*sto VCP reading*/
                    sp.ReadExisting();
                    sampleBufferNum++;

                }
                /*check if all buffers was received*/
                if (sampleBufferNum >= sampleBufferCount) {
                    /*store how many data we readed*/
                    numberOfDataRecieved = vcpSamplesCount * bytesPerSample * sampleBufferNum;
                    /*calculate how many samples we read*/
                    numberOfSamplesRevieced = numberOfDataRecieved / bytesPerSample;
                    /*start fill buffer from beginning*/
                    sampleBufferNum = 0;
                    /*lock process and send data to grah update function*/
                    lock (sp)
                    {
                        /*update graph*/
                        this.Invoke(new EventHandler(DoUpdate));
                    }
                }
            }
            /*error handling*/
            catch (Exception ex)
            {
                /*disconnect VCP*/
                VCP_Diconect();
            }
        }
        /*update graph*/
        public void DoUpdate(object sender, System.EventArgs e)
        {
            int i,x;
            chart1.Series["Series1"].Points.Clear();

            //If correctly triggered shift data values slightly
            //  so the value at x=0 matches trigger value
            int x1 = 0,x2 = 0;
            for (x = bytesPerSample-1; x >=0; --x)
            {
                x1 *= 256;
                x1 += readBuffer[x];
                x2 *= 256;
                x2 += readBuffer[bytesPerSample + x];
            }
            double offsetX = 0.0;
            //Trigger detected (otherwise the offset is set to zero)
            if (triggerRisingEdge)
            {
                if (x1 < triggerValue && x2 >= triggerValue)
                {
                    offsetX = (bytesPerSample * (this.triggerValue - x1)) / (double)(x2 - x1);
                }
            }
            else
            {
                if (x1 >= triggerValue && x2 < triggerValue)
                {
                    offsetX = (bytesPerSample * (this.triggerValue - x1)) / (double)(x2 - x1);
                }
            }

            //Render data into chart
            double lastVal = 0;
            double val = 0;
            double samplestoshow=(double)1000;
            for (i = 0; i < samplestoshow/* numberOfDataRecieved*/; i += bytesPerSample)
            {
                lastVal = val;
                val = 0;
                for (x = bytesPerSample-1; x >=0; --x)
                {
                    val *= 256;
                    val += readBuffer[i + x];
                }
                chart1.Series["Series1"].Points.AddXY((i - offsetX) * sampleIndexToMs, val * sampleToVoltage);
            }

            chart1.Series["Series1"].Points.AddXY((numberOfDataRecieved - offsetX) * sampleIndexToMs, (2*val - lastVal) * sampleToVoltage);

            maxAxisX = sampleIndexToMs * samplestoshow /*numberOfSamplesRevieced** bytesPerSample*/;

            chart1.ChartAreas[0].AxisX.Maximum = maxAxisX;
            chart1.ChartAreas[0].AxisY.Maximum = 3400;

            chart1.Series["Trigger"].Points.Clear();
            chart1.Series["Trigger"].Points.AddXY(0, this.triggerValue * sampleToVoltage);
            chart1.Series["Trigger"].Points.AddXY(numberOfSamplesRevieced, this.triggerValue * sampleToVoltage);
        } 
        /*handle disconnect button*/
        private void button1_Click(object sender, EventArgs e)
        {
#if !USE_LIBUSB
            /*handle errors*/
            try
            {
                /*close port*/
                _serialPort.Close();
            }
            /*eror handling*/
            catch (Exception ex)
            {
                /*disconnect VCP*/
                VCP_Diconect();
                MessageBox.Show("Close error"+ex.ToString());
                return;
            }
            /*clear prograss bar*/
            progressBar1.Value = 0;
#else
            disconnect();
#endif
        }

        private void chart1_MouseMove(object sender, MouseEventArgs e)
        {
            Point mousePoint = new Point(e.X, e.Y);

            chart1.ChartAreas[0].CursorX.IsUserEnabled = true;
            chart1.ChartAreas[0].CursorX.IsUserSelectionEnabled = true;
            chart1.ChartAreas[0].CursorY.IsUserEnabled = true;
            chart1.ChartAreas[0].CursorY.IsUserSelectionEnabled = true;


            chart1.ChartAreas[0].CursorX.SetCursorPixelPosition(mousePoint, true);
            chart1.ChartAreas[0].CursorY.SetCursorPixelPosition(mousePoint, true);


            //textBox1.Text = chart1.ChartAreas[0].CursorX.Position.ToString()+ ", " + chart1.ChartAreas[0].CursorY.Position.ToString();
        }
#if USE_LIBUSB
        private void disconnect()
        {
            if(USB_receive != null){
                lock (USB_receive) {
                    running = false;
                }
                USB_receive.Join();
                USB_receive = null;
            }

            if (MyUsbDevice != null)
            {
                if (MyUsbDevice.IsOpen)
                {
                    // If this is a "whole" usb device (libusb-win32, linux libusb-1.0)
                    // it exposes an IUsbDevice interface. If not (WinUSB) the 
                    // 'wholeUsbDevice' variable will be null indicating this is 
                    // an interface of a device; it does not require or support 
                    // configuration and interface selection.
                    IUsbDevice wholeUsbDevice = MyUsbDevice as IUsbDevice;
                    if (!ReferenceEquals(wholeUsbDevice, null))
                    {
                        // Release interface #0.
                        wholeUsbDevice.ReleaseInterface(0);
                    }

                    MyUsbDevice.Close();
                }
                MyUsbDevice = null;

                // Free usb resources
                UsbDevice.Exit();

            }
        }
#endif
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
#if USE_LIBUSB
            disconnect();
            UsbDevice.Exit();
#endif
        }
        /*unzoom in graph*/
        private void unzoomButton_Click(object sender, EventArgs e)
        {
            chart1.ChartAreas[0].AxisX.ScaleView.Zoom(0.0, numberOfSamplesRevieced);
            chart1.ChartAreas[0].AxisY.ScaleView.Zoom(0.0, maxVoltage);
        }


#if USE_LIBUSB
        private void setTriggerVoltage(double voltage)
        {
            if (writer != null)
            {
                int length;
                byte[] values = new byte[4];
                double dValue = Math.Min(Math.Max(voltage, 0.0), maxVoltage);
                int intValue = (int)(dValue / sampleToVoltage);
                this.triggerValue = intValue;
                values[0] = 0x1;
                values[2] = (byte)(intValue & 0xFF);
                values[3] = (byte)((intValue >> 8) & 0xFF);
                writer.Write(values, 0, 4, 1000, out length);
            }


            chart1.Series["Trigger"].Points.Clear();
            chart1.Series["Trigger"].Points.AddXY(0, voltage);
            chart1.Series["Trigger"].Points.AddXY(numberOfSamplesRevieced, voltage);
        }

        private void setSampleRate(int sampleRate)
        {
            if (writer != null)
            {
                int length;
                byte[] values = new byte[4];
                if (sampleRate < 256) sampleRate = 256;
                if (sampleRate > 10000000) sampleRate = 10000000;
                values[0] = 0x2;
                values[1] = (byte)(sampleRate & 0xFF);
                values[2] = (byte)((sampleRate >> 8) & 0xFF);
                values[3] = (byte)((sampleRate >> 16) & 0xFF);
                writer.Write(values, 0, 4, 1000, out length);
            }

            this.sampleRate = sampleRate;
            sampleIndexToMs = (1e3) / (sampleRate * bytesPerSample);
            maxAxisX = sampleIndexToMs * numberOfSamplesRevieced * bytesPerSample;

            chart1.ChartAreas[0].AxisX.Maximum = maxAxisX;
        }

        private void setNumberOfSamples(int numberOfSamples)
        {
            if (writer != null)
            {
                int length;
                byte[] values = new byte[4];
                int number = (int)numberOfSamples;
                values[0] = 0x3;
                values[1] = (byte)(number & 0xFF);
                values[2] = (byte)((number >> 8) & 0xFF);
                values[3] = (byte)((number >> 16) & 0xFF);
                writer.Write(values, 0, 4, 1000, out length);
            }
        }

        private void setRisingEdge(bool isRising)
        {
            if (writer != null)
            {
                int length;
                byte[] values = new byte[4];
                values[0] = 0x4;
                values[3] = (byte)((isRising) ? 0 : 1);
                writer.Write(values, 0, 4, 1000, out length);
                triggerRisingEdge = isRising;
            }
        }

        private void setTriggerMode(TriggerMode value)
        {
            if (writer != null)
            {
                int length;
                byte[] values = new byte[4];
                values[0] = 0x5;
                values[3] = (byte)((int)(value) & 0xFF);
                writer.Write(values, 0, 4, 1000, out length);
            }
        }
#else
        /*set trigger voltage*/
        private void setTriggerVoltage(double voltage)
        {
            try
            {
                if ((_serialPort != null) && (_serialPort.IsOpen))
                {
                    /*prepare VCP message*/
                    byte[] values = new byte[4];
                    double dValue = Math.Min(Math.Max(voltage, 0.0), maxVoltage);
                    int intValue = (int)(dValue / sampleToVoltage);
                    this.triggerValue = intValue;
                    values[0] = 0x1;
                    values[2] = (byte)(intValue & 0xFF);
                    values[3] = (byte)((intValue >> 8) & 0xFF);
                    /*send prarametes over VCP*/
                    _serialPort.Write(values, 0, 4);
                }
            }
            /*error handling*/
            catch (Exception ex)
            {
                VCP_Diconect();
            }

            chart1.Series["Trigger"].Points.Clear();
            chart1.Series["Trigger"].Points.AddXY(0, voltage);
            chart1.Series["Trigger"].Points.AddXY(numberOfSamplesRevieced, voltage);
        }
        /*set sample rate*/
        private void setSampleRate(int sampleRate)
        {
            try{
                if ((_serialPort!=null)&&(_serialPort.IsOpen))
                {
                    /*prepare VCP message*/
                    byte[] values = new byte[4];
                    if (sampleRate < 256) sampleRate = 256;
                    if (sampleRate > 10000000) sampleRate = 10000000;
                    values[0] = 0x2;
                    values[1] = (byte)(sampleRate & 0xFF);
                    values[2] = (byte)((sampleRate >> 8) & 0xFF);
                    values[3] = (byte)((sampleRate >> 16) & 0xFF);
                    /*send prarametes over VCP*/
                    _serialPort.Write(values, 0, 4);
                

                }
             
            }
            /*error handling*/
            catch (Exception ex)
            {
                VCP_Diconect();
            }

            this.sampleRate = sampleRate;
            sampleIndexToMs = (1e3) / (sampleRate * bytesPerSample);
            maxAxisX = sampleIndexToMs * numberOfSamplesRevieced * bytesPerSample;

            chart1.ChartAreas[0].AxisX.Maximum = maxAxisX;
        }
        /*set number of samples*/
        private void setNumberOfSamples(int numberOfSamples)
        {
            try
            {
                if ((_serialPort != null) && (_serialPort.IsOpen))
                {
                    /*prepare VCP message*/
                    byte[] values = new byte[4];
                    int number = (int)numberOfSamples;
                    values[0] = 0x3;
                    values[1] = (byte)(number & 0xFF);
                    values[2] = (byte)((number >> 8) & 0xFF);
                    values[3] = (byte)((number >> 16) & 0xFF);
                    /*send prarametes over VCP*/
                    _serialPort.Write(values, 0, 4);


                    /*create new read buffer*/
                    readBuffer = new byte[RESOLUTION_10MS.numSamples * 2];
                    /*set number of samples which we want to receive*/
                    vcpSamplesCount = RESOLUTION_10MS.numSamples;
                    /*check if we receive more bytes than is our buffer*/
                    if (vcpSamplesCount > maxSamplesVCPBuffer)
                    {
                        /*check how many buffers we receiving*/
                        int tempval = vcpSamplesCount / maxSamplesVCPBuffer;
                        /*check if last buffer is not full*/
                        if (vcpSamplesCount > (tempval * maxSamplesVCPBuffer))
                        {
                            /*receive one more buffer*/
                            sampleBufferCount = tempval + 1;
                        }
                        else
                        {
                            /*receive only full buffers*/
                            sampleBufferCount = tempval;
                        }
                        vcpSamplesCount = maxSamplesVCPBuffer;
                    }
                    else
                    {
                        /*receive one buffer*/
                        sampleBufferCount = 1;
                    }
                }
            }     
            /*error handling*/
            catch (Exception ex)
            {
                VCP_Diconect();
            }
        }
        /*set trigger rising/falling mode*/
        private void setRisingEdge(bool isRising)
        {
            try 
            { 
                if ((_serialPort != null) && (_serialPort.IsOpen))
                {
                    /*prepare VCP message*/
                    byte[] values = new byte[4];
                    values[0] = 0x4;
                    values[3] = (byte)((isRising) ? 0 : 1);
                    /*send data over VCP*/
                    _serialPort.Write(values, 0, 4);

                    triggerRisingEdge = isRising;
                }
            }
            catch (Exception ex)
            {
                VCP_Diconect();
            }

        }
        /*set trigger mode*/
        private void setTriggerMode(TriggerMode value)
        {
            try
            {
                if ((_serialPort != null) && (_serialPort.IsOpen))
                {
                    /*prepare VCP message*/
                    byte[] values = new byte[4];
                    values[0] = 0x5;
                    values[3] = (byte)((int)(value) & 0xFF);
                    /*send data over VCP*/
                    _serialPort.Write(values, 0, 4);

                }
            }
            /*error handling*/
            catch (Exception ex)
            {
                VCP_Diconect();
            }
        }
#endif
        
        

      
       

      
      
        /*search is the VCP is present in device manager*/
        private string AutodetectSTM32VCPPort()
        {
            /*create management instance*/
            ManagementScope connectionScope = new ManagementScope();
            /*create query instance searching for STM32 VCP*/
            SelectQuery serialQuery = new SelectQuery("SELECT * FROM Win32_SerialPort");
            /*search VCP in device manager*/
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(connectionScope, serialQuery);
            /*handle errors*/
            try
            {
                /*search for VCPs in objects*/
                foreach (ManagementObject item in searcher.Get())
                {
                    /*get descriuption from object*/
                    string desc = item["Description"].ToString();
                    /*get descriuption ID from object*/
                    string deviceId = item["DeviceID"].ToString();
                    /*check if this is STM32 VCP*/
                    if (desc.Contains("STMicroelectronics Virtual COM Port"))
                    {
                        /*yes we found VCP*/
                        return deviceId;
                    }
                }
            }
            /*erro handling*/
            catch (ManagementException e)
            {
                /* Do Nothing */
            }
            /*VCP not exists in debvice manager*/
            return null;
        }


        /*Handle serial port errors*/
        private void serialPort1_ErrorReceived(object sender, SerialErrorReceivedEventArgs e)
        {
           
        }


        /*check is if VCP is present and application use it*/
        private void timer1_Tick(object sender, EventArgs e)
        {
            string port_name;
            timer1.Stop();
            port_name = AutodetectSTM32VCPPort();//find stm vistual com port
            /*VCP not connected*/
            if (port_name==null)
            {
                /*VCP not exists but is open*/
                if ((_serialPort!=null)&&(_serialPort.IsOpen)) 
                {
                    /*is necassary remove receive handler?*/
                    VCP_Diconect();
                    
                }
                timer1.Start();
                return;//close connection handler
            }
            /*the VCP is present and is in use*/
            if (VCP_Open == false)
            {

                // Create a new SerialPort object with default settings.
                _serialPort = new SerialPort();
                /*set encoding for VCP*/
                _serialPort.Encoding = System.Text.Encoding.GetEncoding(28591);

                // Set the read/write timeouts
                _serialPort.ReadTimeout = 500;
                _serialPort.WriteTimeout = 500;

                /*check if the com port is connected*/
                if (port_name == null)
                {
                    MessageBox.Show("STM VCP is not connected to PC");
                    VCP_Diconect();
                    timer1.Start();
                    return;
                }
                /*set VCP number*/
                _serialPort.PortName = port_name;
                /*add DataReceivedHandler handler*/
                _serialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
                try
                {
                    /*open VCP*/
                    _serialPort.Open();
                    /*mark port as in use*/
                    VCP_Open = true;
                }
                /*error during opening*/
                catch (Exception ex)
                {
                    MessageBox.Show("Cannot open Serial com port");
                    VCP_Diconect();
                    timer1.Start();
                    return;
                }
                /*fill progress bar*/
                progressBar1.Value = 100;
            }
            timer1.Start();
        }
        /*disconnect VCP if we want or error occure*/
        private void VCP_Diconect()
        {
            /*try handle errors*/
            try
            {
                /*check if serial port exists and is open*/
                if ((_serialPort != null) && (_serialPort.IsOpen))
                {
                    /*sipose VCP resources*/
                    _serialPort.Dispose();
                }
            }
            /*handle erros during feeing VCP*/
            catch (Exception ex)
            {

            }
            /*delete VCP instance*/
            _serialPort=null;
            /*mark VCP as not used*/
            VCP_Open=false;
            /*empty progress bar*/
            this.Invoke(new EventHandler(ProgressBarUpdateClear));
            
            /*VCP buffer used 0*/
            sampleBufferNum = 0;
        }
        private void ProgressBarUpdateClear(object sender, System.EventArgs e)
        {
            progressBar1.Value = 0;
        }
    }
}
